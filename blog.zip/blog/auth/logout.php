<?php
// auth/logout.php
require_once '../includes/session.php';

// Destroy session and redirect to login page
session_destroy();
header("Location: ../index.php");
exit();
?>