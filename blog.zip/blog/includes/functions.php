<?php
// includes/functions.php
require_once __DIR__ . '/../config/database.php';

// Clean input data
function cleanInput($data) {
    global $conn;
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $conn->real_escape_string($data);
}

// Get user by ID
function getUserById($userId) {
    global $conn;
    $userId = (int)$userId;
    $query = "SELECT * FROM users WHERE id = $userId";
    $result = $conn->query($query);
    
    if ($result && $result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    return false;
}

// Get post by ID
function getPostById($postId) {
    global $conn;
    $postId = (int)$postId;
    $query = "SELECT p.*, u.username, u.profile_picture 
              FROM posts p 
              JOIN users u ON p.user_id = u.id 
              WHERE p.id = $postId";
    $result = $conn->query($query);
    
    if ($result && $result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    return false;
}

// Get all posts
function getAllPosts($limit = 10, $offset = 0) {
    global $conn;
    $limit = (int)$limit;
    $offset = (int)$offset;
    
    $query = "SELECT p.*, u.username, u.profile_picture, 
                    (SELECT COUNT(*) FROM likes WHERE post_id = p.id) as like_count,
                    (SELECT COUNT(*) FROM comments WHERE post_id = p.id) as comment_count
              FROM posts p 
              JOIN users u ON p.user_id = u.id 
              WHERE p.status = 'published'
              ORDER BY p.created_at DESC 
              LIMIT $limit OFFSET $offset";
    
    $result = $conn->query($query);
    $posts = [];
    
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $posts[] = $row;
        }
    }
    
    return $posts;
}

// Get posts by user ID
function getPostsByUserId($userId, $limit = 10, $offset = 0) {
    global $conn;
    $userId = (int)$userId;
    $limit = (int)$limit;
    $offset = (int)$offset;
    
    $query = "SELECT p.*, 
                    (SELECT COUNT(*) FROM likes WHERE post_id = p.id) as like_count,
                    (SELECT COUNT(*) FROM comments WHERE post_id = p.id) as comment_count
              FROM posts p 
              WHERE p.user_id = $userId
              ORDER BY p.created_at DESC 
              LIMIT $limit OFFSET $offset";
    
    $result = $conn->query($query);
    $posts = [];
    
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $posts[] = $row;
        }
    }
    
    return $posts;
}

// Check if user liked a post
function userLikedPost($userId, $postId) {
    global $conn;
    $userId = (int)$userId;
    $postId = (int)$postId;
    
    $query = "SELECT * FROM likes WHERE user_id = $userId AND post_id = $postId";
    $result = $conn->query($query);
    
    return ($result && $result->num_rows > 0);
}

// Get comments for a post
function getCommentsByPostId($postId) {
    global $conn;
    $postId = (int)$postId;
    
    $query = "SELECT c.*, u.username, u.profile_picture 
              FROM comments c 
              JOIN users u ON c.user_id = u.id 
              WHERE c.post_id = $postId 
              ORDER BY c.created_at DESC";
    
    $result = $conn->query($query);
    $comments = [];
    
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $comments[] = $row;
        }
    }
    
    return $comments;
}

// Check if user follows another user
function userFollowsUser($followerId, $followingId) {
    global $conn;
    $followerId = (int)$followerId;
    $followingId = (int)$followingId;
    
    $query = "SELECT * FROM followers WHERE follower_id = $followerId AND following_id = $followingId";
    $result = $conn->query($query);
    
    return ($result && $result->num_rows > 0);
}

// Count followers
function countFollowers($userId) {
    global $conn;
    $userId = (int)$userId;
    
    $query = "SELECT COUNT(*) as count FROM followers WHERE following_id = $userId";
    $result = $conn->query($query);
    
    if ($result && $row = $result->fetch_assoc()) {
        return $row['count'];
    }
    
    return 0;
}

// Count following
function countFollowing($userId) {
    global $conn;
    $userId = (int)$userId;
    
    $query = "SELECT COUNT(*) as count FROM followers WHERE follower_id = $userId";
    $result = $conn->query($query);
    
    if ($result && $row = $result->fetch_assoc()) {
        return $row['count'];
    }
    
    return 0;
}

// Get followers
function getFollowers($userId) {
    global $conn;
    $userId = (int)$userId;
    
    $query = "SELECT u.* FROM followers f 
              JOIN users u ON f.follower_id = u.id 
              WHERE f.following_id = $userId";
    
    $result = $conn->query($query);
    $followers = [];
    
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $followers[] = $row;
        }
    }
    
    return $followers;
}

// Get following
function getFollowing($userId) {
    global $conn;
    $userId = (int)$userId;
    
    $query = "SELECT u.* FROM followers f 
              JOIN users u ON f.following_id = u.id 
              WHERE f.follower_id = $userId";
    
    $result = $conn->query($query);
    $following = [];
    
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $following[] = $row;
        }
    }
    
    return $following;
}

// Format date
function formatDate($date) {
    return date("F j, Y, g:i a", strtotime($date));
}

// Truncate text
function truncateText($text, $length = 150) {
    if (strlen($text) > $length) {
        return substr($text, 0, $length) . '...';
    }
    return $text;
}

// Count posts by user
function countPostsByUser($userId) {
    global $conn;
    $userId = (int)$userId;
    
    $query = "SELECT COUNT(*) as count FROM posts WHERE user_id = $userId";
    $result = $conn->query($query);
    
    if ($result && $row = $result->fetch_assoc()) {
        return $row['count'];
    }
    
    return 0;
}

// Upload image
function uploadImage($file, $directory = '../assets/images/uploads/') {
    $target_dir = $directory;
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }
    
    $fileName = basename($file["name"]);
    $targetFilePath = $target_dir . $fileName;
    $fileType = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));
    
    // Generate unique filename
    $fileName = uniqid() . '.' . $fileType;
    $targetFilePath = $target_dir . $fileName;
    
    // Allow certain file formats
    $allowTypes = array('jpg', 'png', 'jpeg', 'gif');
    if (!in_array($fileType, $allowTypes)) {
        return false;
    }
    
    // Upload file
    if (move_uploaded_file($file["tmp_name"], $targetFilePath)) {
        return $fileName;
    }
    
    return false;
}
?>