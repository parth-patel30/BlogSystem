<?php
// includes/footer.php
?>
<head>
<link rel="shortcut icon" href="https://cdn-icons-png.flaticon.com/512/786/786194.png" type="image/png">    
<link rel="stylesheet" href="../assets/css/style.css">
</head>
    <footer class="text-black mt-5 py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5>Blog System</h5>
                    <p>A simple yet powerful blogging platform.</p>
                </div>
                <div class="col-md-3">
                    <h5>Quick Links</h5>
                    <ul class="list-unstyled">
                        <li><a href="/blog/index.php" class="text-black">Home</a></li>
                        <?php if (isLoggedIn()): ?>
                            <li><a href="/blog/blog/create.php" class="text-black">Create Post</a></li>
                            <li><a href="/blog/user/profile.php?username=<?php echo getCurrentUsername(); ?>" class="text-white">My Profile</a></li>
                        <?php else: ?>
                            <li><a href="/blog/auth/login.php" class="black-white">Login</a></li>
                            <li><a href="/blog/auth/signup.php" class="text-black">Sign Up</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
               
                </div>
            </div>
            <hr>
            <div class="text-center">
                <p class="mb-0">&copy; <?php echo date('Y'); ?> Blog System. All rights reserved.</p>
            </div>
        </div>  
    </footer>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</body>
</html>