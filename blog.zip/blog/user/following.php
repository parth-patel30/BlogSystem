<?php
// user/following.php
require_once '../includes/session.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

// Get user ID from URL or use current user ID
$user_id = isset($_GET['id']) ? (int)$_GET['id'] : getCurrentUserId();

// Redirect to login if not logged in and no user ID provided
if (!$user_id) {
    header("Location: ../auth/login.php");
    exit();
}

// Get user details
$user = getUserById($user_id);

if (!$user) {
    header("Location: ../index.php");
    exit();
}

// Get following
$following = getFollowing($user_id);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Following - <?php echo $user['username']; ?> - Blog System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="shortcut icon" href="https://cdn-icons-png.flaticon.com/512/786/786194.png" type="image/png">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include_once '../includes/header.php'; ?>
    
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow">
                    <div class="card-header bg-white d-flex justify-content-between align-items-center">
                        <h4 class="mb-0">Users <?php echo $user['username']; ?> is Following</h4>
                        <a href="profile.php?id=<?php echo $user_id; ?>" class="btn btn-sm btn-outline-primary">Back to Profile</a>
                    </div>
                    <div class="card-body">
                        <?php if (empty($following)): ?>
                            <div class="text-center py-5">
                                <p class="text-muted">Not following anyone yet</p>
                            </div>
                        <?php else: ?>
                            <ul class="list-group list-group-flush">
                                <?php foreach ($following as $follow): ?>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <div class="d-flex align-items-center">
                                            <img src="../assets/images/<?php echo $follow['profile_picture']; ?>" alt="<?php echo $follow['username']; ?>" 
                                                class="rounded-circle me-3" style="width: 50px; height: 50px; object-fit: cover;">
                                            <div>
                                                <h6 class="mb-0"><?php echo $follow['full_name'] ?: $follow['username']; ?></h6>
                                                <small class="text-muted">@<?php echo $follow['username']; ?></small>
                                            </div>
                                        </div>
                                        <a href="profile.php?id=<?php echo $follow['id']; ?>" class="btn btn-sm btn-outline-primary">View Profile</a>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php include_once '../includes/footer.php'; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/script.js"></script>
</body>
</html>