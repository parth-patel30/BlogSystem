<?php
// user/edit-profile.php
require_once '../includes/session.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

// Require login
requireLogin();

$user_id = getCurrentUserId();
$user = getUserById($user_id);

$error = '';
$success = false;

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = cleanInput($_POST["full_name"] ?? '');
    $bio = cleanInput($_POST["bio"] ?? '');
    $email = cleanInput($_POST["email"]);
    
    // Validate email
    if (empty($email)) {
        $error = "Email is required";
    } else {
        // Check if email is already in use by another user
        $query = "SELECT * FROM users WHERE email = '$email' AND id != $user_id";
        $result = $conn->query($query);
        
        if ($result && $result->num_rows > 0) {
            $error = "Email already in use by another account";
        } else {
            $profile_picture = $user['profile_picture'];
            
            // Handle profile picture upload if present
            if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['size'] > 0) {
                $new_picture = uploadImage($_FILES['profile_picture']);
                if ($new_picture) {
                    $profile_picture = $new_picture;
                } else {
                    $error = "Invalid image format. Only JPG, JPEG, PNG, and GIF are allowed.";
                }
            }
            
            // Update password if provided
            $password_update = "";
            if (!empty($_POST["new_password"])) {
                $current_password = $_POST["current_password"];
                $new_password = $_POST["new_password"];
                $confirm_password = $_POST["confirm_password"];
                
                if (empty($current_password)) {
                    $error = "Current password is required to change password";
                } elseif (strlen($new_password) < 6) {
                    $error = "New password must be at least 6 characters long";
                } elseif ($new_password !== $confirm_password) {
                    $error = "New passwords do not match";
                } else {
                    // Verify current password
                    if (password_verify($current_password, $user["password"])) {
                        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                        $password_update = ", password = '$hashed_password'";
                    } else {
                        $error = "Current password is incorrect";
                    }
                }
            }
            
            if (empty($error)) {
                // Update user profile
                $query = "UPDATE users SET 
                          full_name = '$full_name', 
                          bio = '$bio', 
                          email = '$email', 
                          profile_picture = '$profile_picture'
                          $password_update
                          WHERE id = $user_id";
                
                if ($conn->query($query)) {
                    $success = true;
                } else {
                    $error = "Error: " . $conn->error;
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile - Blog System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="shortcut icon" href="https://cdn-icons-png.flaticon.com/512/786/786194.png" type="image/png">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include_once '../includes/header.php'; ?>
    
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0">Edit Profile</h4>
                    </div>
                    <div class="card-body">
                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <?php if ($success): ?>
                            <div class="alert alert-success">Profile updated successfully!</div>
                        <?php endif; ?>
                        
                        <form action="edit-profile.php" method="post" enctype="multipart/form-data">
                            <div class="mb-3 text-center">
                                <img src="../assets/images/uploads/<?php echo $user['profile_picture']; ?>" alt="Profile Picture" class="rounded-circle mb-3" style="width: 150px; height: 150px; object-fit: cover;">
                                <div class="mb-3">
                                    <label for="profile_picture" class="form-label">Change Profile Picture</label>
                                    <input type="file" class="form-control" id="profile_picture" name="profile_picture">
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="username" class="form-label">Username</label>
                                <input type="text" class="form-control" id="username" value="<?php echo $user['username']; ?>" disabled>
                                <small class="text-muted">Username cannot be changed</small>
                            </div>
                            
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="email" name="email" value="<?php echo $user['email']; ?>" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="full_name" class="form-label">Full Name</label>
                                <input type="text" class="form-control" id="full_name" name="full_name" value="<?php echo $user['full_name']; ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label for="bio" class="form-label">Bio</label>
                                <textarea class="form-control" id="bio" name="bio" rows="3"><?php echo $user['bio']; ?></textarea>
                            </div>
                            
                            <hr>
                            <h5>Change Password</h5>
                            <p class="text-muted small">Leave blank if you don't want to change your password</p>
                            
                            <div class="mb-3">
                                <label for="current_password" class="form-label">Current Password</label>
                                <input type="password" class="form-control" id="current_password" name="current_password">
                            </div>
                            
                            <div class="mb-3">
                                <label for="new_password" class="form-label">New Password</label>
                                <input type="password" class="form-control" id="new_password" name="new_password">
                                <small class="text-muted">Minimum 6 characters</small>
                            </div>
                            
                            <div class="mb-3">
                                <label for="confirm_password" class="form-label">Confirm New Password</label>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password">
                            </div>
                            
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary">Save Changes</button>
                                <a href="profile.php" class="btn btn-outline-secondary">Cancel</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php include_once '../includes/footer.php'; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/script.js"></script>
</body>
</html>