<?php
// user/profile.php
require_once '../includes/session.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

// Get user ID from URL or use current user ID
$user_id = isset($_GET['id']) ? (int)$_GET['id'] : getCurrentUserId();

// Redirect to login if not logged in and no user ID provided
if (!$user_id) {
    header("Location: ../auth/login.php");
    exit();
}

// Get user details
$user = getUserById($user_id);

if (!$user) {
    header("Location: ../index.php");
    exit();
}

// Get user posts
$posts = getPostsByUserId($user_id, 10);

// Get stats
$post_count = countPostsByUser($user_id);
$follower_count = countFollowers($user_id);
$following_count = countFollowing($user_id);

// Check if current user follows this user
$is_following = false;
if (isLoggedIn() && $user_id != getCurrentUserId()) {
    $is_following = userFollowsUser(getCurrentUserId(), $user_id);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $user['username']; ?> - Profile - Blog System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="shortcut icon" href="https://cdn-icons-png.flaticon.com/512/786/786194.png" type="image/png">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include_once '../includes/header.php'; ?>
    
    <div class="container py-5">
        <div class="row">
            <div class="col-lg-4 mb-4">
                <div class="card shadow">
                    <div class="card-body text-center">
                        <img src="../assets/images/uploads/<?php echo $user['profile_picture']; ?>" alt="<?php echo $user['username']; ?>" class="rounded-circle img-fluid mb-3" style="width: 150px; height: 150px; object-fit: cover;">
                        
                        <h3 class="card-title"><?php echo $user['full_name'] ?: $user['username']; ?></h3>
                        <p class="text-muted">@<?php echo $user['username']; ?></p>
                        
                        <?php if (!empty($user['bio'])): ?>
                            <p class="card-text"><?php echo $user['bio']; ?></p>
                        <?php endif; ?>
                        
                        <p class="text-muted">Joined: <?php echo formatDate($user['created_at']); ?></p>
                        
                        <div class="d-flex justify-content-center mb-3">
                            <div class="px-3">
                                <h5><?php echo $post_count; ?></h5>
                                <small class="text-muted">Posts</small>
                            </div>
                            <div class="px-3 border-start border-end">
                                <h5><a href="followers.php?id=<?php echo $user_id; ?>" class="text-decoration-none"><?php echo $follower_count; ?></a></h5>
                                <small class="text-muted">Followers</small>
                            </div>
                            <div class="px-3">
                                <h5><a href="following.php?id=<?php echo $user_id; ?>" class="text-decoration-none"><?php echo $following_count; ?></a></h5>
                                <small class="text-muted">Following</small>
                            </div>
                        </div>
                        
                        <?php if (isLoggedIn()): ?>
                            <?php if ($user_id == getCurrentUserId()): ?>
                                <a href="edit-profile.php" class="btn btn-primary">Edit Profile</a>
                            <?php else: ?>
                                <button class="btn <?php echo $is_following ? 'btn-secondary' : 'btn-primary'; ?> follow-btn" 
                                        data-user-id="<?php echo $user_id; ?>" 
                                        data-action="<?php echo $is_following ? 'unfollow' : 'follow'; ?>">
                                    <?php echo $is_following ? 'Unfollow' : 'Follow'; ?>
                                </button>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-8">
                <div class="card shadow mb-4">
                    <div class="card-header bg-white">
                        <h4 class="mb-0">Posts</h4>
                    </div>
                    <div class="card-body">
                        <?php if (empty($posts)): ?>
                            <div class="text-center py-5">
                                <p class="text-muted">No posts yet</p>
                            </div>
                        <?php else: ?>
                            <?php foreach ($posts as $post): ?>
                                <div class="card mb-3">
                                    <div class="card-body">
                                        <h5 class="card-title">
                                            <a href="../blog/post.php?id=<?php echo $post['id']; ?>" class="text-decoration-none"><?php echo $post['title']; ?></a>
                                        </h5>
                                       
                                        <div class="d-flex justify-content-between">
                                            <small class="text-muted">
                                                <i class="bi bi-calendar"></i> <?php echo formatDate($post['created_at']); ?>
                                            </small>
                                            <div>
                                                <span class="me-3">
                                                    <i class="bi bi-heart<?php echo userLikedPost(getCurrentUserId(), $post['id']) ? '-fill text-danger' : ''; ?>"></i> 
                                                    <?php echo $post['like_count'] ?? 0; ?>
                                                </span>
                                                <span>
                                                    <i class="bi bi-chat"></i> 
                                                    <?php echo $post['comment_count'] ?? 0; ?>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php include_once '../includes/footer.php'; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="../assets/js/script.js"></script>
</body>
</html>