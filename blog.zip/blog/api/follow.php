<?php
// api/follow.php
require_once '../includes/session.php';
require_once '../config/database.php';

// Require login
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Login required']);
    exit();
}

// Check if user_id is provided
if (!isset($_POST['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'User ID is required']);
    exit();
}

$following_id = (int)$_POST['user_id'];
$follower_id = getCurrentUserId();

// Cannot follow yourself
if ($follower_id == $following_id) {
    echo json_encode(['success' => false, 'message' => 'Cannot follow yourself']);
    exit();
}

// Check if user exists
$query = "SELECT * FROM users WHERE id = $following_id";
$result = $conn->query($query);

if (!$result || $result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'User not found']);
    exit();
}

// Check if already following
$query = "SELECT * FROM followers WHERE follower_id = $follower_id AND following_id = $following_id";
$result = $conn->query($query);

if ($result && $result->num_rows > 0) {
    // Already following, so unfollow
    $query = "DELETE FROM followers WHERE follower_id = $follower_id AND following_id = $following_id";
    if ($conn->query($query)) {
        echo json_encode([
            'success' => true, 
            'action' => 'unfollowed'
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $conn->error]);
    }
} else {
    // Not following, so follow
    $query = "INSERT INTO followers (follower_id, following_id) VALUES ($follower_id, $following_id)";
    if ($conn->query($query)) {
        echo json_encode([
            'success' => true, 
            'action' => 'followed'
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $conn->error]);
    }
}
?>