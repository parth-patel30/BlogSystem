<?php
// api/unfollow.php
header('Content-Type: application/json');
require_once '../includes/session.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

// Require login for this action
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Login required']);
    exit();
}

$response = ['success' => false, 'message' => 'Invalid request'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get user ID to unfollow from request
    $following_id = isset($_POST['user_id']) ? (int)$_POST['user_id'] : 0;
    $follower_id = getCurrentUserId();
    
    if ($following_id <= 0) {
        $response['message'] = 'Invalid user ID';
    } else {
        // Check if user exists
        $user = getUserById($following_id);
        if (!$user) {
            $response['message'] = 'User not found';
        } else {
            // Check if following
            if (!userFollowsUser($follower_id, $following_id)) {
                $response['message'] = 'You are not following this user';
            } else {
                // Remove follow relationship
                $query = "DELETE FROM followers WHERE follower_id = $follower_id AND following_id = $following_id";
                if ($conn->query($query)) {
                    $response = [
                        'success' => true, 
                        'message' => 'Successfully unfollowed user',
                        'follower_count' => countFollowers($following_id)
                    ];
                } else {
                    $response['message'] = 'Error unfollowing user: ' . $conn->error;
                }
            }
        }
    }
}

echo json_encode($response);
?>