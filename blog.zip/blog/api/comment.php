<?php
// api/comment.php
require_once '../includes/session.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

// Check if user is logged in
if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

// Check request method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit();
}

// Get data
$post_id = isset($_POST['post_id']) ? (int)$_POST['post_id'] : 0;
$comment = isset($_POST['comment']) ? cleanInput($_POST['comment']) : '';
$user_id = getCurrentUserId();

// Validate data
if (!$post_id) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid post ID']);
    exit();
}

if (empty($comment)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Comment cannot be empty']);
    exit();
}

// Check if post exists
$post = getPostById($post_id);
if (!$post) {
    http_response_code(404);
    echo json_encode(['success' => false, 'message' => 'Post not found']);
    exit();
}

// Add comment
$query = "INSERT INTO comments (post_id, user_id, comment) VALUES ($post_id, $user_id, '$comment')";
$result = $conn->query($query);

if ($result) {
    $comment_id = $conn->insert_id;
    
    // Get the comment with user info
    $query = "SELECT c.*, u.username, u.profile_picture 
              FROM comments c 
              JOIN users u ON c.user_id = u.id 
              WHERE c.id = $comment_id";
    
    $comment_result = $conn->query($query);
    
    if ($comment_result && $comment_data = $comment_result->fetch_assoc()) {
        $comment_data['created_at_formatted'] = formatDate($comment_data['created_at']);
        
        echo json_encode([
            'success' => true, 
            'message' => 'Comment added successfully', 
            'comment' => $comment_data
        ]);
    } else {
        echo json_encode([
            'success' => true, 
            'message' => 'Comment added successfully'
        ]);
    }
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Failed to add comment']);
}
?>