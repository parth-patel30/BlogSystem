<?php
// api/like.php
require_once '../includes/session.php';
require_once '../config/database.php';

// Require login
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Login required']);
    exit();
}

// Check if post_id is provided
if (!isset($_POST['post_id'])) {
    echo json_encode(['success' => false, 'message' => 'Post ID is required']);
    exit();
}

$post_id = (int)$_POST['post_id'];
$user_id = getCurrentUserId();

// Check if post exists
$query = "SELECT * FROM posts WHERE id = $post_id";
$result = $conn->query($query);

if (!$result || $result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Post not found']);
    exit();
}

// Check if user already liked the post
$query = "SELECT * FROM likes WHERE post_id = $post_id AND user_id = $user_id";
$result = $conn->query($query);

if ($result && $result->num_rows > 0) {
    // User already liked, so unlike
    $query = "DELETE FROM likes WHERE post_id = $post_id AND user_id = $user_id";
    if ($conn->query($query)) {
        // Get updated like count
        $count_query = "SELECT COUNT(*) as count FROM likes WHERE post_id = $post_id";
        $count_result = $conn->query($count_query);
        $count = ($count_result && $row = $count_result->fetch_assoc()) ? $row['count'] : 0;
        
        echo json_encode([
            'success' => true, 
            'action' => 'unliked',
            'count' => $count
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $conn->error]);
    }
} else {
    // User hasn't liked, so add like
    $query = "INSERT INTO likes (post_id, user_id) VALUES ($post_id, $user_id)";
    if ($conn->query($query)) {
        // Get updated like count
        $count_query = "SELECT COUNT(*) as count FROM likes WHERE post_id = $post_id";
        $count_result = $conn->query($count_query);
        $count = ($count_result && $row = $count_result->fetch_assoc()) ? $row['count'] : 0;
        
        echo json_encode([
            'success' => true, 
            'action' => 'liked',
            'count' => $count
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $conn->error]);
    }
}
?>