<?php
// index.php
require_once 'includes/session.php';
require_once 'config/database.php';
require_once 'includes/functions.php';

// Get posts with pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 5;
$offset = ($page - 1) * $limit;

$posts = getAllPosts($limit, $offset);

// Get total posts for pagination
$query = "SELECT COUNT(*) as total FROM posts WHERE status = 'published'";
$result = $conn->query($query);
$total_posts = $result->fetch_assoc()['total'];
$total_pages = ceil($total_posts / $limit);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog System</title>
    <link rel="shortcut icon" href="https://cdn-icons-png.flaticon.com/512/786/786194.png" type="image/png">
    <meta name="theme-color" content="#06c1db">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php include_once 'includes/header.php'; ?>
    
    <div class="container py-5">
        <div class="row">
            <!-- Main Content -->
            <div class="col-lg-8">
                <h1 class="mb-4">Latest Blog Posts</h1>
                
                <?php if (empty($posts)): ?>
                    <div class="alert alert-info">No posts found.</div>
                <?php else: ?>
                    <?php foreach ($posts as $post): ?>
                        <div class="card mb-4 shadow-sm">
                            <div class="card-body">
                                <div class="d-flex align-items-center mb-3">
                                    <img src="assets/images/uploads/<?php echo $post['profile_picture']; ?>" 
                                         alt="Profile" class="rounded-circle me-2" 
                                         style="width: 40px; height: 40px; object-fit: cover;">
                                    <div>
                                        <h6 class="mb-0"><?php echo htmlspecialchars($post['username']); ?></h6>
                                        <small class="text-muted"><?php echo formatDate($post['created_at']); ?></small>
                                    </div>
                                </div>
                                
                                <h3 class="card-title">
                                    <a href="blog/post.php?id=<?php echo $post['id']; ?>" class="text-decoration-none">
                                        <?php echo htmlspecialchars($post['title']); ?>
                                    </a>
                                </h3>
                                
                                <?php if ($post['image']): ?>
                                    <img src="assets/images/uploads/<?php echo $post['image']; ?>" 
                                         alt="Post Image" class="img-fluid rounded mb-3">
                                <?php endif; ?>
                                
                                <div class="card-text mb-3">
                                    <?php echo html_entity_decode(truncateText($post['content'], 300)); ?>
                                </div>
                                
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <span class="me-3">
                                            <i class="bi bi-heart"></i> <?php echo $post['like_count']; ?> likes
                                        </span>
                                        <span>
                                            <i class="bi bi-chat"></i> <?php echo $post['comment_count']; ?> comments
                                        </span>
                                    </div>
                                    <a href="blog/post.php?id=<?php echo $post['id']; ?>" class="btn btn-primary btn-sm">Read More</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                    
                    <!-- Pagination -->
                    <?php if ($total_pages > 1): ?>
                        <nav aria-label="Page navigation">
                            <ul class="pagination justify-content-center">
                                <?php if ($page > 1): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?page=<?php echo $page - 1; ?>">Previous</a>
                                    </li>
                                <?php endif; ?>
                                
                                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                    <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                        <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                                    </li>
                                <?php endfor; ?>
                                
                                <?php if ($page < $total_pages): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?page=<?php echo $page + 1; ?>">Next</a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            
            <!-- Sidebar -->
            <div class="col-lg-4">
                <div class="card mb-4 shadow-sm">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">Welcome!</h5>
                    </div>
                    <div class="card-body">
                        <?php if (isLoggedIn()): ?>
                            <p>Hello, <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong>!</p>
                            <div class="d-grid gap-2">
                                <a href="blog/create.php" class="btn btn-primary">Create New Post</a>
                                <a href="user/profile.php?username=<?php echo $_SESSION['username']; ?>" class="btn btn-outline-primary">View Profile</a>
                            </div>
                        <?php else: ?>
                            <p>Join our community to share your thoughts and connect with others!</p>
                            <div class="d-grid gap-2">
                                <a href="auth/login.php" class="btn btn-primary">Login</a>
                                <a href="auth/signup.php" class="btn btn-outline-primary">Sign Up</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Popular Posts -->
                <div class="card shadow-sm">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">Popular Posts</h5>
                    </div>
                    <div class="card-body">
                        <?php
                        $popular_query = "SELECT p.id, p.title, COUNT(l.id) as like_count 
                                         FROM posts p 
                                         LEFT JOIN likes l ON p.id = l.post_id 
                                         WHERE p.status = 'published' 
                                         GROUP BY p.id 
                                         ORDER BY like_count DESC 
                                         LIMIT 5";
                        $popular_result = $conn->query($popular_query);
                        
                        if ($popular_result && $popular_result->num_rows > 0):
                        ?>
                            <ul class="list-group list-group-flush">
                                <?php while ($pop_post = $popular_result->fetch_assoc()): ?>
                                    <li class="list-group-item">
                                        <a href="blog/post.php?id=<?php echo $pop_post['id']; ?>" class="text-decoration-none">
                                            <?php echo htmlspecialchars($pop_post['title']); ?>
                                        </a>
                                        <span class="badge bg-primary float-end"><?php echo $pop_post['like_count']; ?> likes</span>
                                    </li>
                                <?php endwhile; ?>
                            </ul>
                        <?php else: ?>
                            <p class="text-muted">No popular posts yet.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php include_once 'includes/footer.php'; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="assets/js/script.js"></script>
</body>
</html>