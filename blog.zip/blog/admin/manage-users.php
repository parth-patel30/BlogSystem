<?php
// admin/manage-users.php
require_once '../includes/session.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

// Require admin privileges
requireAdmin();

$error = '';
$success = '';

// Handle user role change
if (isset($_POST['change_role'])) {
    $user_id = (int)$_POST['user_id'];
    $new_role = cleanInput($_POST['role']);
    
    if ($user_id != getCurrentUserId()) { // Prevent admin from changing own role
        $query = "UPDATE users SET role = '$new_role' WHERE id = $user_id";
        if ($conn->query($query)) {
            $success = "User role updated successfully";
        } else {
            $error = "Error updating role: " . $conn->error;
        }
    } else {
        $error = "You cannot change your own role";
    }
}

// Handle user deletion
if (isset($_GET['delete'])) {
    $user_id = (int)$_GET['delete'];
    
    if ($user_id != getCurrentUserId()) { // Prevent admin from deleting themselves
        $query = "DELETE FROM users WHERE id = $user_id";
        if ($conn->query($query)) {
            $success = "User deleted successfully";
        } else {
            $error = "Error deleting user: " . $conn->error;
        }
    } else {
        $error = "You cannot delete your own account";
    }
}

// Pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// Search functionality
$search = isset($_GET['search']) ? cleanInput($_GET['search']) : '';
$search_condition = '';
if (!empty($search)) {
    $search_condition = "WHERE username LIKE '%$search%' OR email LIKE '%$search%' OR full_name LIKE '%$search%'";
}

// Get total users count for pagination
$count_query = "SELECT COUNT(*) as total FROM users $search_condition";
$count_result = $conn->query($count_query);
$total_users = $count_result->fetch_assoc()['total'];
$total_pages = ceil($total_users / $limit);

// Get users with pagination and search
$query = "SELECT * FROM users $search_condition ORDER BY created_at DESC LIMIT $limit OFFSET $offset";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="shortcut icon" href="https://cdn-icons-png.flaticon.com/512/786/786194.png" type="image/png">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include_once '../includes/header.php'; ?>
    
    <div class="container-fluid py-4">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2">
                <?php include_once 'sidebar.php'; ?>
            </div>
            
            <!-- Main content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Manage Users</h1>
                </div>
                
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>
                
                <!-- Search form -->
                <div class="row mb-4">
                    <div class="col-md-6">
                        <form action="" method="get" class="d-flex">
                            <input type="text" name="search" class="form-control me-2" placeholder="Search users..." value="<?php echo $search; ?>">
                            <button type="submit" class="btn btn-primary">Search</button>
                            <?php if (!empty($search)): ?>
                                <a href="manage-users.php" class="btn btn-secondary ms-2">Clear</a>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
                
                <!-- Users table -->
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Full Name</th>
                                <th>Role</th>
                                <th>Posts</th>
                                <th>Registered Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($result && $result->num_rows > 0): ?>
                                <?php while ($user = $result->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo $user['id']; ?></td>
                                        <td><?php echo $user['username']; ?></td>
                                        <td><?php echo $user['email']; ?></td>
                                        <td><?php echo $user['full_name'] ?? 'N/A'; ?></td>
                                        <td>
                                            <form action="manage-users.php" method="post" class="d-flex">
                                                <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                <select name="role" class="form-select form-select-sm" <?php echo ($user['id'] == getCurrentUserId()) ? 'disabled' : ''; ?>>
                                                    <option value="user" <?php echo ($user['role'] == 'user') ? 'selected' : ''; ?>>User</option>
                                                    <option value="admin" <?php echo ($user['role'] == 'admin') ? 'selected' : ''; ?>>Admin</option>
                                                </select>
                                                <button type="submit" name="change_role" class="btn btn-sm btn-outline-primary ms-2" <?php echo ($user['id'] == getCurrentUserId()) ? 'disabled' : ''; ?>>Update</button>
                                            </form>
                                        </td>
                                        <td><?php echo countPostsByUser($user['id']); ?></td>
                                        <td><?php echo formatDate($user['created_at']); ?></td>
                                        <td>
                                            <a href="../user/profile.php?id=<?php echo $user['id']; ?>" class="btn btn-sm btn-info">View</a>
                                            <?php if ($user['id'] != getCurrentUserId()): ?>
                                                <a href="manage-users.php?delete=<?php echo $user['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this user? This action cannot be undone.')">Delete</a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="8" class="text-center">No users found</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                    <nav aria-label="Page navigation">
                        <ul class="pagination justify-content-center">
                            <li class="page-item <?php echo ($page <= 1) ? 'disabled' : ''; ?>">
                                <a class="page-link" href="<?php echo "?page=" . ($page - 1) . (!empty($search) ? "&search=$search" : ""); ?>">Previous</a>
                            </li>
                            
                            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                <li class="page-item <?php echo ($page == $i) ? 'active' : ''; ?>">
                                    <a class="page-link" href="<?php echo "?page=$i" . (!empty($search) ? "&search=$search" : ""); ?>"><?php echo $i; ?></a>
                                </li>
                            <?php endfor; ?>
                            
                            <li class="page-item <?php echo ($page >= $total_pages) ? 'disabled' : ''; ?>">
                                <a class="page-link" href="<?php echo "?page=" . ($page + 1) . (!empty($search) ? "&search=$search" : ""); ?>">Next</a>
                            </li>
                        </ul>
                    </nav>
                <?php endif; ?>
            </main>
        </div>
    </div>
    
    <?php include_once '../includes/footer.php'; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/script.js"></script>
</body>
</html>