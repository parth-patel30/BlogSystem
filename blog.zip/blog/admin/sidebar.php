<?php
// admin/sidebar.php
$current_page = basename($_SERVER['PHP_SELF']);
?>

<div class="list-group mb-4">
    <div class="list-group-item bg-primary text-white">
        <h5 class="mb-0">Admin Panel</h5>
    </div>
    <a href="dashboard.php" class="list-group-item list-group-item-action <?php echo $current_page == 'dashboard.php' ? 'active' : ''; ?>">
        <i class="bi bi-speedometer2 me-2"></i> Dashboard
    </a>
    <a href="manage-posts.php" class="list-group-item list-group-item-action <?php echo $current_page == 'manage-posts.php' ? 'active' : ''; ?>">
        <i class="bi bi-file-earmark-text me-2"></i> Manage Posts
    </a>
    <a href="manage-users.php" class="list-group-item list-group-item-action <?php echo $current_page == 'manage-users.php' ? 'active' : ''; ?>">
        <i class="bi bi-people me-2"></i> Manage Users
    </a>
    <a href="settings.php" class="list-group-item list-group-item-action <?php echo $current_page == 'settings.php' ? 'active' : ''; ?>">
        <i class="bi bi-gear me-2"></i> Settings
    </a>
    <a href="../index.php" class="list-group-item list-group-item-action">
        <i class="bi bi-house me-2"></i> Back to Site
    </a>
</div>

<div class="card">
    <div class="card-header text-white">
        <h5 class="mb-0">Quick Actions</h5>
    </div>
    <div class="card-body">
        <div class="d-grid gap-2">
            <a href="../blog/create.php" class="btn btn-success">
                <i class="bi bi-plus-circle me-2"></i> Add New Post
            </a>
        </div>
    </div>
</div>