<?php
// admin/settings.php
require_once '../includes/session.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

// Require admin privileges
requireAdmin();

$error = '';
$success = '';

// Handle settings update
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['update_password'])) {
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        
        // Get current user
        $user_id = getCurrentUserId();
        $user = getUserById($user_id);
        
        if (!password_verify($current_password, $user['password'])) {
            $error = "Current password is incorrect";
        } elseif ($new_password !== $confirm_password) {
            $error = "New passwords do not match";
        } elseif (strlen($new_password) < 6) {
            $error = "Password must be at least 6 characters long";
        } else {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $query = "UPDATE users SET password = '$hashed_password' WHERE id = $user_id";
            
            if ($conn->query($query)) {
                $success = "Password updated successfully";
            } else {
                $error = "Error updating password: " . $conn->error;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="shortcut icon" href="https://cdn-icons-png.flaticon.com/512/786/786194.png" type="image/png">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        #side1{
            padding-top:59px;
        }
    </style>
</head>
    
    <body>
    <?php include_once '../includes/header.php'; ?>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 bg-light min-vh-10" id="side1">
                <?php include 'sidebar.php'; ?>
            </div>

            <!-- Main content -->
            <main class="col-md-10 ms-auto p-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Admin Settings</h1>
                </div>

                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>

                <?php if ($success): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-md-6">
                        <div class="card shadow mb-4">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Change Password</h5>
                            </div>
                            <div class="card-body">
                                <form action="settings.php" method="post">
                                    <div class="mb-3">
                                        <label for="current_password" class="form-label">Current Password</label>
                                        <input type="password" class="form-control" id="current_password" name="current_password" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="new_password" class="form-label">New Password</label>
                                        <input type="password" class="form-control" id="new_password" name="new_password" required>
                                        <small class="text-muted">Minimum 6 characters</small>
                                    </div>
                                    <div class="mb-3">
                                        <label for="confirm_password" class="form-label">Confirm New Password</label>
                                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                                    </div>
                                    <button type="submit" name="update_password" class="btn btn-primary">Update Password</button>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="card shadow mb-4">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Admin Information</h5>
                            </div>
                            <div class="card-body">
                                <?php $current_user = getUserById(getCurrentUserId()); ?>
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Username</label>
                                    <p><?php echo $current_user['username']; ?></p>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Email</label>
                                    <p><?php echo $current_user['email']; ?></p>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Role</label>
                                    <p><span class="badge bg-primary"><?php echo ucfirst($current_user['role']); ?></span></p>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Account Created</label>
                                    <p><?php echo formatDate($current_user['created_at']); ?></p>
                                </div>
                                <a href="../user/edit-profile.php" class="btn btn-outline-primary">Edit Profile</a>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <?php include_once '../includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/script.js"></script>
</body>
</html>