<?php
// blog/delete.php
require_once '../includes/session.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

// Require login
requireLogin();

// Check if post ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: ../index.php");
    exit();
}

$post_id = (int)$_GET['id'];
$post = getPostById($post_id);

// Check if post exists and user has permission
if (!$post || ($post['user_id'] != getCurrentUserId() && !isAdmin())) {
    header("Location: ../index.php");
    exit();
}

$error = '';
$confirm = isset($_GET['confirm']) && $_GET['confirm'] == 'yes';

// Handle deletion
if ($confirm) {
    // Delete the post
    $query = "DELETE FROM posts WHERE id = $post_id";
    
    if ($conn->query($query)) {
        // Redirect to homepage
        header("Location: ../index.php?deleted=true");
        exit();
    } else {
        $error = "Error deleting post: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Post - Blog System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="shortcut icon" href="https://cdn-icons-png.flaticon.com/512/786/786194.png" type="image/png">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include_once '../includes/header.php'; ?>
    
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow">
                    <div class="card-header bg-danger text-white">
                        <h4 class="mb-0">Delete Post</h4>
                    </div>
                    <div class="card-body">
                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <?php if (!$confirm): ?>
                            <div class="alert alert-warning">
                                <p class="mb-0">Are you sure you want to delete the post "<strong><?php echo $post['title']; ?></strong>"?</p>
                                <p class="mb-0">This action cannot be undone.</p>
                            </div>
                            
                            <div class="d-flex justify-content-between mt-4">
                                <a href="post.php?id=<?php echo $post_id; ?>" class="btn btn-secondary">Cancel</a>
                                <a href="delete.php?id=<?php echo $post_id; ?>&confirm=yes" class="btn btn-danger">Yes, Delete Post</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php include_once '../includes/footer.php'; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/script.js"></script>
</body>
</html>