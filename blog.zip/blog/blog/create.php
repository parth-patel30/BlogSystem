<?php
// blog/create.php
require_once '../includes/session.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

// Require login
requireLogin();

$error = '';
$success = false;

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = cleanInput($_POST["title"]);
    $content = cleanInput($_POST["content"]);
    $status = cleanInput($_POST["status"] ?? 'published');
    $user_id = getCurrentUserId();
    
    // Validate input
    if (empty($title) || empty($content)) {
        $error = "Title and content are required";
    } else {
        $image = null;
        
        // Handle image upload if present
        if (isset($_FILES['image']) && $_FILES['image']['size'] > 0) {
            $image = uploadImage($_FILES['image']);
            if (!$image) {
                $error = "Invalid image format. Only JPG, JPEG, PNG, and GIF are allowed.";
            }
        }
        
        if (empty($error)) {
            // Insert new post
            $query = "INSERT INTO posts (user_id, title, content, image, status) 
                      VALUES ('$user_id', '$title', '$content', '$image', '$status')";
            
            if ($conn->query($query)) {
                $post_id = $conn->insert_id;
                $success = true;
            } else {
                $error = "Error: " . $conn->error;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create New Post - Blog System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css">
    <link rel="shortcut icon" href="https://cdn-icons-png.flaticon.com/512/786/786194.png" type="image/png">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include_once '../includes/header.php'; ?>
    
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0">Create New Post</h4>
                    </div>
                    <div class="card-body">
                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <?php if ($success): ?>
                            <div class="alert alert-success">
                                Post created successfully! 
                                <a href="post.php?id=<?php echo $post_id; ?>">View Post</a> or 
                                <a href="create.php">Create Another</a>
                            </div>
                        <?php else: ?>
                            <form action="create.php" method="post" enctype="multipart/form-data">
                                <div class="mb-3">
                                    <label for="title" class="form-label">Title</label>
                                    <input type="text" class="form-control" id="title" name="title" required>
                                </div>
                                <div class="mb-3">
                                    <label for="content" class="form-label">Content</label>
                                    <textarea class="form-control" id="content" name="content" rows="10" required></textarea>
                                </div>
                                <div class="mb-3">
                                    <label for="image" class="form-label">Featured Image (Optional)</label>
                                    <input type="file" class="form-control" id="image" name="image">
                                </div>
                                <div class="mb-3">
                                    <label for="status" class="form-label">Status</label>
                                    <select class="form-select" id="status" name="status">
                                        <option value="published">Published</option>
                                        <option value="draft">Draft</option>
                                    </select>
                                </div>
                                <button type="submit" class="btn btn-primary">Create Post</button>
                                <a href="../index.php" class="btn btn-secondary">Cancel</a>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php include_once '../includes/footer.php'; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>
    <script src="../assets/js/script.js"></script>
    <script>
        $(document).ready(function() {
            $('#content').summernote({
                placeholder: 'Write your post content here...',
                height: 300,
                toolbar: [
                    ['style', ['style']],
                    ['font', ['bold', 'underline', 'clear']],
                    ['color', ['color']],
                    ['para', ['ul', 'ol', 'paragraph']],
                    ['table', ['table']],
                    ['insert', ['link', 'picture']],
                    ['view', ['fullscreen', 'codeview', 'help']]
                ]
            });
        });
    </script>
</body>
</html>