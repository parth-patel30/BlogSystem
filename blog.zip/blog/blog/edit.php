<?php
// blog/edit.php
require_once '../includes/session.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

// Require login
requireLogin();

// Get post ID from URL
$post_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$error = '';
$success = false;

// Validate post ID
if ($post_id <= 0) {
    header("Location: ../index.php");
    exit();
}

// Get post details
$post = getPostById($post_id);
if (!$post) {
    header("Location: ../index.php");
    exit();
}

// Check if user has permission to edit
if ($post['user_id'] != getCurrentUserId() && !isAdmin()) {
    header("Location: post.php?id=$post_id");
    exit();
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = cleanInput($_POST["title"]);
    $content = $_POST["content"]; // Don't clean HTML content
    $status = cleanInput($_POST["status"] ?? 'published');
    
    // Validate input
    if (empty($title) || empty($content)) {
        $error = "Title and content are required";
    } else {
        $updateImage = '';
        
        // Handle image upload if present
        if (isset($_FILES['image']) && $_FILES['image']['size'] > 0) {
            $image = uploadImage($_FILES['image']);
            if (!$image) {
                $error = "Invalid image format. Only JPG, JPEG, PNG, and GIF are allowed.";
            } else {
                $updateImage = ", image = '$image'";
            }
        }
        
        if (empty($error)) {
            // Prepare statement
            $stmt = $conn->prepare("UPDATE posts SET title = ?, content = ?, status = ? WHERE id = ?");
            
            // If there's an image update
            if (!empty($updateImage)) {
                $stmt = $conn->prepare("UPDATE posts SET title = ?, content = ?, status = ?, image = ? WHERE id = ?");
                $stmt->bind_param("ssssi", $title, $content, $status, $image, $post_id);
            } else {
                $stmt->bind_param("sssi", $title, $content, $status, $post_id);
            }
            
            if ($stmt->execute()) {
                $success = true;
                // Refresh post data
                $post = getPostById($post_id);
            } else {
                $error = "Error: " . $stmt->error;
            }
            $stmt->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Post - Blog System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css" rel="stylesheet">
    <link rel="shortcut icon" href="https://cdn-icons-png.flaticon.com/512/786/786194.png" type="image/png">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include_once '../includes/header.php'; ?>
    
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0">Edit Post</h4>
                    </div>
                    <div class="card-body">
                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <?php if ($success): ?>
                            <div class="alert alert-success">
                                Post updated successfully! 
                                <a href="post.php?id=<?php echo $post_id; ?>">View Post</a>
                            </div>
                        <?php endif; ?>
                        
                        <form action="edit.php?id=<?php echo $post_id; ?>" method="post" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label for="title" class="form-label">Title</label>
                                <input type="text" class="form-control" id="title" name="title" 
                                       value="<?php echo htmlspecialchars($post['title']); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="content" class="form-label">Content</label>
                                <textarea class="form-control summernote" id="content" name="content" rows="10" required><?php echo $post['content']; ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="status" class="form-label">Status</label>
                                <select class="form-select" id="status" name="status">
                                    <option value="published" <?php echo $post['status'] == 'published' ? 'selected' : ''; ?>>
                                        Published
                                    </option>
                                    <option value="draft" <?php echo $post['status'] == 'draft' ? 'selected' : ''; ?>>
                                        Draft
                                    </option>
                                </select>
                            </div>
                            <?php if ($post['image']): ?>
                                <div class="mb-3">
                                    <label class="form-label">Current Image</label>
                                    <div>
                                        <img src="../assets/images/uploads/<?php echo $post['image']; ?>" 
                                             alt="<?php echo htmlspecialchars($post['title']); ?>" 
                                             class="img-thumbnail" style="max-height: 200px;">
                                    </div>
                                </div>
                            <?php endif; ?>
                            <div class="mb-3">
                                <label for="image" class="form-label">Update Image (optional)</label>
                                <input type="file" class="form-control" id="image" name="image">
                                <small class="text-muted">Leave empty to keep the current image</small>
                            </div>
                            <div class="d-flex justify-content-between">
                                <a href="post.php?id=<?php echo $post_id; ?>" class="btn btn-secondary">Cancel</a>
                                <button type="submit" class="btn btn-primary">Update Post</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php include_once '../includes/footer.php'; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>
    <script src="../assets/js/script.js"></script>
    
    <script>
    $(document).ready(function() {
        $('.summernote').summernote({
            height: 300,
            toolbar: [
                ['style', ['style']],
                ['font', ['bold', 'underline', 'clear']],
                ['color', ['color']],
                ['para', ['ul', 'ol', 'paragraph']],
                ['table', ['table']],
                ['view', ['fullscreen', 'codeview', 'help']]
            ]
        });
    });
    </script>
</body>
</html>