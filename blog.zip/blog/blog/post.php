<?php
// blog/post.php
require_once '../includes/session.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

// Get post ID from URL
$post_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$error = '';
$commentError = '';
$commentSuccess = false;

// Validate post ID
if ($post_id <= 0) {
    header("Location: ../index.php");
    exit();
}

// Get post details
$post = getPostById($post_id);
if (!$post) {
    header("Location: ../index.php");
    exit();
}

// Handle comment submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['comment'])) {
    if (!isLoggedIn()) {
        $commentError = "You must be logged in to comment";
    } else {
        $comment = cleanInput($_POST['comment']);
        $user_id = getCurrentUserId();
        
        if (empty($comment)) {
            $commentError = "Comment cannot be empty";
        } else {
            $query = "INSERT INTO comments (post_id, user_id, comment) 
                      VALUES ($post_id, $user_id, '$comment')";
            
            if ($conn->query($query)) {
                $commentSuccess = true;
            } else {
                $commentError = "Error: " . $conn->error;
            }
        }
    }
}

// Get comments for this post
$comments = getCommentsByPostId($post_id);

// Check if current user liked this post
$userLiked = isLoggedIn() ? userLikedPost(getCurrentUserId(), $post_id) : false;

// Get like count
$query = "SELECT COUNT(*) as count FROM likes WHERE post_id = $post_id";
$result = $conn->query($query);
$likeCount = ($result && $row = $result->fetch_assoc()) ? $row['count'] : 0;

// Get post author details
$author = getUserById($post['user_id']);

// Check if current user follows the author
$userFollowsAuthor = isLoggedIn() && $post['user_id'] != getCurrentUserId() ? 
                     userFollowsUser(getCurrentUserId(), $post['user_id']) : false;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($post['title']); ?> - Blog System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="shortcut icon" href="https://cdn-icons-png.flaticon.com/512/786/786194.png" type="image/png">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include_once '../includes/header.php'; ?>
    
    <div class="container py-5">
        <div class="row">
            <div class="col-md-8">
                <div class="card shadow mb-4">
                    <div class="card-body">
                        <h1 class="card-title"><?php echo htmlspecialchars($post['title']); ?></h1>
                        
                        <div class="d-flex align-items-center mb-3">
                            <img src="../assets/images/uploads/<?php echo $post['profile_picture']; ?>" 
                                 alt="<?php echo htmlspecialchars($post['username']); ?>" 
                                 class="rounded-circle me-2" 
                                 style="width: 40px; height: 40px; object-fit: cover;">
                            <div>
                                <a href="../user/profile.php?id=<?php echo $post['user_id']; ?>" class="text-decoration-none">
                                    <?php echo htmlspecialchars($post['username']); ?>
                                </a>
                                <div class="text-muted small">
                                    <?php echo formatDate($post['created_at']); ?>
                                </div>
                            </div>
                        </div>
                        
                        <?php if ($post['image']): ?>
                            <img src="../assets/images/uploads/<?php echo $post['image']; ?>" 
                                 alt="<?php echo htmlspecialchars($post['title']); ?>" 
                                 class="img-fluid rounded mb-3">
                        <?php endif; ?>
                        
                        <div class="post-content mb-4">
                            <?php echo html_entity_decode($post['content']); ?>
                        </div>
                        
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="d-flex align-items-center">
                                <?php if (isLoggedIn()): ?>
                                    <button class="btn btn-sm <?php echo $userLiked ? 'btn-danger' : 'btn-outline-danger'; ?> me-2 like-btn"
                                            data-post-id="<?php echo $post_id; ?>">
                                        <i class="fas fa-heart"></i> 
                                        <span class="like-count"><?php echo $likeCount; ?></span>
                                    </button>
                                <?php else: ?>
                                    <button class="btn btn-sm btn-outline-danger me-2" disabled>
                                        <i class="fas fa-heart"></i> 
                                        <span><?php echo $likeCount; ?></span>
                                    </button>
                                <?php endif; ?>
                                
                                <button class="btn btn-sm btn-outline-primary">
                                    <i class="fas fa-comment"></i> 
                                    <span><?php echo count($comments); ?></span>
                                </button>
                            </div>
                            
                            <?php if (isLoggedIn() && (getCurrentUserId() == $post['user_id'] || isAdmin())): ?>
                                <div>
                                    <a href="edit.php?id=<?php echo $post_id; ?>" class="btn btn-sm btn-outline-primary me-2">
                                        <i class="fas fa-edit"></i> Edit
                                    </a>
                                    <a href="#" class="btn btn-sm btn-outline-danger delete-post-btn" data-post-id="<?php echo $post_id; ?>">
                                        <i class="fas fa-trash"></i> Delete
                                    </a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- Comments Section -->
                <div class="card shadow">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">Comments (<?php echo count($comments); ?>)</h5>
                    </div>
                    <div class="card-body">
                        <?php if ($commentError): ?>
                            <div class="alert alert-danger"><?php echo $commentError; ?></div>
                        <?php endif; ?>
                        
                        <?php if ($commentSuccess): ?>
                            <div class="alert alert-success">Comment added successfully!</div>
                        <?php endif; ?>
                        
                        <?php if (isLoggedIn()): ?>
                            <form action="post.php?id=<?php echo $post_id; ?>" method="post" class="mb-4">
                                <div class="mb-3">
                                    <label for="comment" class="form-label">Add a Comment</label>
                                    <textarea class="form-control" id="comment" name="comment" rows="3" required></textarea>
                                </div>
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </form>
                        <?php else: ?>
                            <div class="alert alert-info mb-4">
                                Please <a href="../auth/login.php">login</a> to leave a comment.
                            </div>
                        <?php endif; ?>
                        
                        <div class="comments-list">
                            <?php if (count($comments) > 0): ?>
                                <?php foreach ($comments as $comment): ?>
                                    <div class="comment mb-3 p-3 border rounded">
                                        <div class="d-flex align-items-center mb-2">
                                            <img src="../assets/images/uploads/<?php echo $comment['profile_picture']; ?>" 
                                                 alt="<?php echo htmlspecialchars($comment['username']); ?>" 
                                                 class="rounded-circle me-2" 
                                                 style="width: 32px; height: 32px; object-fit: cover;">
                                            <div>
                                                <a href="../user/profile.php?id=<?php echo $comment['user_id']; ?>" class="text-decoration-none fw-bold">
                                                    <?php echo htmlspecialchars($comment['username']); ?>
                                                </a>
                                                <div class="text-muted small">
                                                    <?php echo formatDate($comment['created_at']); ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="comment-text">
                                            <?php echo nl2br(htmlspecialchars($comment['comment'])); ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <div class="text-center text-muted py-3">
                                    <p>No comments yet. Be the first to comment!</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <!-- Author Card -->
                <div class="card shadow mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">About the Author</h5>
                    </div>
                    <div class="card-body text-center">
                        <img src="../assets/images/uploads/<?php echo $author['profile_picture']; ?>" 
                             alt="<?php echo htmlspecialchars($author['username']); ?>" 
                             class="rounded-circle mb-3" 
                             style="width: 100px; height: 100px; object-fit: cover;">
                        <h5><?php echo htmlspecialchars($author['username']); ?></h5>
                        
                        <?php if ($author['full_name']): ?>
                            <p class="text-muted"><?php echo htmlspecialchars($author['full_name']); ?></p>
                        <?php endif; ?>
                        
                        <?php if ($author['bio']): ?>
                            <p><?php echo nl2br(htmlspecialchars($author['bio'])); ?></p>
                        <?php endif; ?>
                        
                        <div class="d-flex justify-content-center gap-3 mb-3">
                            <div class="text-center">
                                <h6><?php echo countPostsByUser($author['id']); ?></h6>
                                <small class="text-muted">Posts</small>
                            </div>
                            <div class="text-center">
                                <h6><?php echo countFollowers($author['id']); ?></h6>
                                <small class="text-muted">Followers</small>
                            </div>
                            <div class="text-center">
                                <h6><?php echo countFollowing($author['id']); ?></h6>
                                <small class="text-muted">Following</small>
                            </div>
                        </div>
                        
                        <?php if (isLoggedIn() && getCurrentUserId() != $author['id']): ?>
                            <button class="btn <?php echo $userFollowsAuthor ? 'btn-secondary' : 'btn-primary'; ?> follow-btn w-100" 
                                    data-user-id="<?php echo $author['id']; ?>">
                                <?php echo $userFollowsAuthor ? 'Unfollow' : 'Follow'; ?>
                            </button>
                        <?php endif; ?>
                        
                        <a href="../user/profile.php?id=<?php echo $author['id']; ?>" class="btn btn-outline-primary mt-2 w-100">
                            View Profile
                        </a>
                    </div>
                </div>
                
                <!-- Recent Posts -->
                <div class="card shadow">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">More from this Author</h5>
                    </div>
                    <div class="card-body">
                        <?php 
                        $recent_posts = getPostsByUserId($author['id'], 5);
                        if (count($recent_posts) > 0): 
                        ?>
                            <ul class="list-group list-group-flush">
                                <?php foreach ($recent_posts as $recent_post): ?>
                                    <?php if ($recent_post['id'] != $post_id): ?>
                                        <li class="list-group-item border-0 px-0">
                                            <a href="post.php?id=<?php echo $recent_post['id']; ?>" class="text-decoration-none">
                                                <?php echo htmlspecialchars($recent_post['title']); ?>
                                            </a>
                                            <div class="text-muted small">
                                                <?php echo formatDate($recent_post['created_at']); ?>
                                            </div>
                                        </li>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </ul>
                        <?php else: ?>
                            <p class="text-muted">No other posts from this author.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php include_once '../includes/footer.php'; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="../assets/js/script.js"></script>
    
    <script>
    $(document).ready(function() {
        // Like/Unlike post
        $('.like-btn').click(function() {
            const postId = $(this).data('post-id');
            const likeButton = $(this);
            const likeCount = likeButton.find('.like-count');
            
            $.ajax({
                url: '../api/like.php',
                type: 'POST',
                data: {post_id: postId},
                success: function(response) {
                    const data = JSON.parse(response);
                    if (data.success) {
                        if (data.action === 'liked') {
                            likeButton.removeClass('btn-outline-danger').addClass('btn-danger');
                        } else {
                            likeButton.removeClass('btn-danger').addClass('btn-outline-danger');
                        }
                        likeCount.text(data.count);
                    }
                }
            });
        });
        
        // Follow/Unfollow user
        $('.follow-btn').click(function() {
            const userId = $(this).data('user-id');
            const followButton = $(this);
            
            $.ajax({
                url: '../api/follow.php',
                type: 'POST',
                data: {user_id: userId},
                success: function(response) {
                    const data = JSON.parse(response);
                    if (data.success) {
                        if (data.action === 'followed') {
                            followButton.removeClass('btn-primary').addClass('btn-secondary');
                            followButton.text('Unfollow');
                        } else {
                            followButton.removeClass('btn-secondary').addClass('btn-primary');
                            followButton.text('Follow');
                        }
                    }
                }
            });
        });
        
        // Delete post confirmation
        $('.delete-post-btn').click(function(e) {
            e.preventDefault();
            const postId = $(this).data('post-id');
            
            if (confirm('Are you sure you want to delete this post? This action cannot be undone.')) {
                window.location.href = 'delete.php?id=' + postId;
            }
        });
    });
    </script>
</body>
</html>